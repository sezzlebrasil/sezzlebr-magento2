<?php
/*
 * @category    Sezzle
 * @package     Sezzle_Sezzlepay
 * @copyright   Copyright (c) Sezzle (https://www.sezzle.com/)
 */

namespace Sezzle\Sezzlepay\Controller\Tokenize;

use Sezzle\Sezzlepay\Controller\Payment\Complete;

class PaymentComplete extends Complete
{
}
